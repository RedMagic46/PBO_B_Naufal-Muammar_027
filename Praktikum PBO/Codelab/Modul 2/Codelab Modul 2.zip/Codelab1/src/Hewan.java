public class Hewan {
    String nama, jenis, suara; // Atribut untuk menyimpan informasi hewan

    // Method untuk menampilkan info tentang hewan
    void tampilkanInfo(){
        System.out.println("Nama: " + nama); // Menampilkan nama hewan
        System.out.println("Jenis: " + jenis); // Menampilkan jenis hewan
        System.out.println("Suara: " + suara + "\n"); // Menampilkan suara hewan
    }
}
