package main.java.com.praktikum.gui;

public class MainApp {
}
